#!/bin/bash
reload(){
	systemctl reload prometheus
	rsync -avz --delete /data/app/prometheus/rules/ root@10.16.3.131:/data/app/prometheus/rules/    > /dev/null 2>&1
	ssh root@10.16.3.131 "systemctl reload prometheus"
}
reload
