# -*- coding: utf-8 -*-

filepath = '/data/app/prometheus/rules'

services = ['taojiji', 'api-taojiji','ops','dev','other','db']

alarms = ['warning', 'average', 'high', 'disaster']

target = '127.0.0.1'
